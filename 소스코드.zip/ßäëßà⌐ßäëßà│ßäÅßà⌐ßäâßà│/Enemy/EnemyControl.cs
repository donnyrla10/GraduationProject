﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//빌런의 플레이어 추적 조정 스크립트 (ch02)

public class EnemyControl : MonoBehaviour
{
    [SerializeField] private PlayerItemnEvent itemPickUp;
    string name;
    int length;

    void Start(){
        name = gameObject.name.ToString();
        length = name.Length;
    }
    void FixedUpdate(){
        if(itemPickUp.chasingStart){
            if(name[length-1].Equals('k')) 
                gameObject.GetComponent<EnemyMovement>().enabled = false;
            gameObject.GetComponent<AgentEnemy>().enabled = true;
        }else{
            if(name[length-1].Equals('k'))
                gameObject.GetComponent<EnemyMovement>().enabled = true;
            gameObject.GetComponent<AgentEnemy>().enabled = false;
        }
    }
}
