﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//enemy 이동 스크립트

public class EnemyMovement : MonoBehaviour{
    [SerializeField]    public string[] villanAnimation= {"normalW_walk", "normalM_walk", "Lv1_W_walk", "Lv1_M_walk", "Lv2_W_walk", "Lv2_M_walk", "Lv3_W_walk", "Lv3_M_walk"};
    SpriteRenderer spriteRenderer;
    Animator animator;

    public float Max = 5.0f; // 최대값(상, 우)
    public float Min = -5.0f; // 최대값(하, 좌)
    public int direction_speed = 5; // 이동속도
    Vector2 currentPostion; //현재 위치 저장
    Vector2 staticPosition;

    private bool collision, flip;
    int newD, index; // 새로운 방향 랜덤 받기

    void Start(){
        Setting();
        currentPostion = transform.position;
        staticPosition = currentPostion;
        spriteRenderer = gameObject.GetComponentInChildren<SpriteRenderer>();
        animator = gameObject.GetComponent<Animator>();
        newD = Random.Range(0,2); // 0 나오면 좌우 이동, 1 나오면 상하 이동
    }

    //enemy의 이동 -> 좌우이동, 콜라이더와 부딪히면 반대로 이동
    void FixedUpdate(){
        if(index != -1){
            animator.Play(villanAnimation[index]);
            if(newD == 0) { //left and right
                if(collision){
                    //부딪히면 이제 그 위치가 max/min 위치임.
                    if(currentPostion.x > staticPosition.x)    Max = currentPostion.x - staticPosition.x;
                    else                                       Min = currentPostion.x - staticPosition.x;
                    collision = false;
                }
                currentPostion.x += Time.deltaTime * direction_speed;
                if(currentPostion.x >= (Max+staticPosition.x) || currentPostion.x <= (Min+staticPosition.x)){
                    flip = !flip;
                    spriteRenderer.flipX = flip;
                    direction_speed *= -1;
                }
                transform.position = currentPostion;
            }

            else if(newD == 1) { //up and down
                if(collision){
                    //부딪히면 이제 그 위치가 max/min 위치임.
                    if(currentPostion.y > staticPosition.y)    Max = currentPostion.y - staticPosition.y;
                    else                                       Min = currentPostion.y - staticPosition.y;
                    collision = false;
                }
                currentPostion.y += Time.deltaTime * direction_speed;
                if(currentPostion.y >= (Max+staticPosition.y) || currentPostion.y <= (Min+staticPosition.y)){
                    flip = !flip;
                    spriteRenderer.flipX = flip;
                    direction_speed *= -1;
                }
                transform.position = currentPostion;
            }
        }   
    }

    void OnCollisionStay2D(Collision2D other){
        if(other.gameObject.CompareTag("HOUSE") || other.gameObject.CompareTag("boundary"))
            collision = true;
    }

    //enemy 애니메이션 변경 인덱스 함수
    void Setting(){
        if(gameObject.name.Equals("normalW_walk"))         index = 0;
        else if(gameObject.name.Equals("normalM_walk"))    index = 1;
        else if(gameObject.name.Equals("Lv1_W_walk"))      index = 2;
        else if(gameObject.name.Equals("Lv1_M_walk"))      index = 3;
        else if(gameObject.name.Equals("Lv2_W_walk"))      index = 4;
        else if(gameObject.name.Equals("Lv2_M_walk"))      index = 5;
        else if(gameObject.name.Equals("Lv3_W_walk"))      index = 6;
        else if(gameObject.name.Equals("Lv3_M_walk"))      index = 7;
        else                                               index = -1;
    }
}
