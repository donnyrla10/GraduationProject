﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

//빌런의 플레이어 추적 스크립트 (ch02)

public class AgentEnemy : MonoBehaviour
{
    [SerializeField] public string[] villanAnimation= {"normalW_walk", "normalM_walk", "Lv1_W_walk", "Lv1_M_walk", "Lv2_W_walk", "Lv2_M_walk", "Lv3_W_walk", "Lv3_M_walk"};
    [SerializeField] public Transform target;
    
    SpriteRenderer spriteRenderer;
    Animator animator;
    private NavMeshAgent agent;
    int index;

    void Start(){
        Setting();
        spriteRenderer = gameObject.GetComponentInChildren<SpriteRenderer>();
        animator = gameObject.GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;
        if(index!=-1)   gameObject.GetComponent<EnemyMovement>().enabled = false;
    }

    void FixedUpdate(){
        if(index != -1)    animator.Play(villanAnimation[index]);
        StartChasing();
    }

    //플레이어 추적 함수
    void StartChasing(){
        if(transform.position.x > target.position.x)         spriteRenderer.flipX = true;
        else if(transform.position.x < target.position.x)    spriteRenderer.flipX = false;
        agent.SetDestination(target.position);
    }

    void Setting(){
        if(gameObject.name.Equals("normalW_walk"))         index = 0;
        else if(gameObject.name.Equals("normalM_walk"))    index = 1;
        else if(gameObject.name.Equals("Lv1_W_walk"))      index = 2;
        else if(gameObject.name.Equals("Lv1_M_walk"))      index = 3;
        else if(gameObject.name.Equals("Lv2_W_walk"))      index = 4;
        else if(gameObject.name.Equals("Lv2_M_walk"))      index = 5;
        else if(gameObject.name.Equals("Lv3_W_walk"))      index = 6;
        else if(gameObject.name.Equals("Lv3_M_walk"))      index = 7;
        else                                               index = -1;
    }
}
