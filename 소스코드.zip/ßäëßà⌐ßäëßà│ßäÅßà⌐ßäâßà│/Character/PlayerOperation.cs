﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Player에 붙는 플레이어 조작, 관련 애니메이션 script
//PlayerState.cs, PlayerDamaged.cs, PlayerItemnEvent.cs 와 연동

public class PlayerOperation : MonoBehaviour
{
    //캐릭터 상황에 따른 애니메이션
    //0: 마스크 없고 말짱한 상태 1: 마스크 있고 멀쩡한 상태, 2: 마스크 없고 힘든 상태, 3: 마스크 있고 힘든 상태
    public string[] idleAnimation = {"Idle01", "Idle02", "Idle03", "Idle04"};
    public string[] walkAnimation = {"Walk01", "Walk02", "Walk03", "Walk04"};
    public string[] damagedAnimation= {"Damage01", "Damage02", "Damage03", "Damage04"};
    public string[] deadAnimation= {"Dead03", "Dead04"};

    [SerializeField]
    private GameObject alarmUI;

    public float movementSpeed = 10.0f, current_speed; //플레이어 이동 속도
    private float moveH, moveV;
    public int alarm=0;
    public int index;
    public bool isZ = false, isdoor=false, new_quest=false, isMap = false, isTicket;

    [SerializeField]
    private PlayerItemnEvent pickup;
    [SerializeField]
    private PlayerState playerState;
    [SerializeField]
    private PlayerDamaged playerDamaged;
    [SerializeField]
    private QuestChange questChange;

    [SerializeField]
    private GameObject go_SlotsParents; //Slot들(3~4개)의 부모인 Grid Setting
    private Slots[] _slots;  //슬롯들 배열
    Rigidbody2D rbody;
    SpriteRenderer spriteRenderer;
    Animator animator;

    public Animator message_animator;
    public AudioSource item_sound, collect_sound, door_sound;

    void Awake(){
        rbody = gameObject.GetComponent<Rigidbody2D>();
        animator = gameObject.GetComponent<Animator>();
        spriteRenderer = gameObject.GetComponentInChildren<SpriteRenderer>();
        _slots = go_SlotsParents.GetComponentsInChildren<Slots>();
        index = 0;
    }

    void FixedUpdate(){
        if(index==2 && index==3)    current_speed = 6.0f;
        else                        current_speed = 10.0f;

        if(playerDamaged.isAttacked) {
            movementSpeed = 0f;
            animator.Play(damagedAnimation[index]);
            playerDamaged.isAttacked = false;
        }
        else            
            movementSpeed = current_speed;

        ManiKey();
        Move();
    }

    public void SetDefault(){
        isZ = false;
        isdoor = false;
        isTicket = false;
    }

    void ManiKey(){
        //item 수집
        if(Input.GetKeyDown("z")){
            collect_sound.Play();
            isZ = true;
            pickup.PickUp();   
        }

        //티켓 수집(다른 아이템과 차이점을 둠)
        else if(Input.GetKeyDown("v")){
            collect_sound.Play();
            isTicket = true;
            pickup.GetTicket();
        }

        //check message
        else if(Input.GetKeyDown("x")){
            if(!message_animator.GetBool("show")) {
                message_animator.SetBool("show",true);
                movementSpeed = 0f;
                if(alarm == 0) //알림이 온 메세지를 한번 확인하면 alarm 아이콘을 끈다.
                    alarmUI.SetActive(false);
                
            }
            else {
                message_animator.SetBool("show",false);
                movementSpeed = current_speed;
                if(alarm == 0)  {
                    new_quest = true;
                    alarm++;   //알람을 한번 확인하고 끄면 alarm변수를 +1해서 다음 퀘스트까지 울리지 않도록 한다. 다음 퀘스트나오면 alarm--해준다.
                }
            }
            if(questChange.Q4)
                questChange.Q4 = false;
        }
        //문 열기/닫기
        else if(Input.GetKeyDown("c")){
            isdoor = true;
            pickup.OpenDoor();
            door_sound.Play();
        }

        //일시 정지 - option열기/닫기
        else if(Input.GetKeyDown(KeyCode.Space))
            pickup.Pause();
        

        //아이템 사용
        else if(Input.GetKeyDown("1")){
            if(_slots[0].items != null){
                _slots[0].UseItem();
                item_sound.Play();
            }
            
        }
        else if(Input.GetKeyDown("2")){
            _slots[1].UseItem();
            item_sound.Play();
        }

        // map열기/닫기
        else if(Input.GetKeyDown("/")){
            isMap = !isMap;
            pickup.Map();
        }
    }

    //player 이동 제어
    void Move(){
        moveH = Input.GetAxis("Horizontal") * movementSpeed;
        moveV = Input.GetAxis("Vertical") * movementSpeed;

        if((Input.GetAxis("Horizontal") == 0) && (Input.GetAxis("Vertical") == 0))
            animator.Play(idleAnimation[index]);
        if(Input.GetAxisRaw("Horizontal") < 0){
            spriteRenderer.flipX = true;        //left filp
            animator.Play(walkAnimation[index]);
        }
        else if(Input.GetAxisRaw("Horizontal") > 0){
            spriteRenderer.flipX= false;        //right flip
            animator.Play(walkAnimation[index]);
        }
        else if(Input.GetAxis("Vertical") != 0)
            animator.Play(walkAnimation[index]);

        rbody.velocity = new Vector2(moveH, moveV);
        Vector2 direction = new Vector2(moveH, moveV);
    }

    public void AnimationIndex(int i){
        index = i;
    }
}

