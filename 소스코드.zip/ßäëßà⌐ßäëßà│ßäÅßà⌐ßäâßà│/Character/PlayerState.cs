﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//player 상태 script
//state에 따른 player animation 변경(PlayerMovement.cs의 AnimationIndex()함수 사용)
//player의 state에 따른 HP slider, Time slider(mask available time) 관리
//player state에 따른 Game over, Retry 관리

public class PlayerState : MonoBehaviour
{
    //hp gauge
    public Slider sliderHP;
    public int hp=100;

    //mask's time limit
    public Slider sliderTime;
    private float time;
    private bool timeStart = false, onMask;
    
    public AudioSource damage_sound;
        
    [SerializeField]
    private CanvasGroup maskTime;
    [SerializeField]
    private PlayerOperation playerOperation;
    [SerializeField]
    private CanvasGroup gameover;
    [SerializeField]
    private CanvasGroup sickFace;
    [SerializeField]
    private GameObject MaskAura;

    void Awake(){
        MaskAura.SetActive(false);
    }

    //state에 따른 animation 변경
    //Hp량 변경
    void FixedUpdate(){
        hp = (int)sliderHP.value;

        //마스크 사용 시간 제한
        if(timeStart){
            time -= Time.deltaTime;
            SetTime();
        }
        
        //state에 따른 animation  
        if(hp <= 40){
            if(onMask)                playerOperation.AnimationIndex(3);
            else                      playerOperation.AnimationIndex(2);
            sickFace.alpha = 1;
        }else{
            if(onMask)                playerOperation.AnimationIndex(1);
            else                      playerOperation.AnimationIndex(0);
            sickFace.alpha = 0;
        }
    }

    //마스크 아이템 사용 함수
    public void UseMask(int feature){
        MaskAura.SetActive(true);
        onMask = true;
        maskTime.alpha = 1;
        sliderTime.maxValue = feature;
        time = feature;
        timeStart = true;
    }

    //HP 세팅 함수
    public void SetHP(int amount, int plus){ 
        if(plus == 0){          // hp 추가
            hp += amount;
            if(hp > 100)           hp = 100;
            sliderHP.value = hp;
        }else{
            damage_sound.Play();
            hp -= amount;
            if(hp <= 0)            GameOver();
            sliderHP.value = hp;
        }            
    }

    //시간 세팅 함수
    void SetTime(){
        if(time <= 0){
            MaskAura.SetActive(false);
            maskTime.alpha = 0;
            timeStart = false;
            onMask = false;                
            return;
        }
        sliderTime.value = time;
    }

    //게임 오버 함수
    void GameOver(){
        gameover.alpha = 1;
        gameover.interactable = true;
        gameover.blocksRaycasts = true;
    }

    //다시 시작 함수
    public void Retry(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        gameover.alpha = 0;
        gameover.interactable = false;
        gameover.blocksRaycasts = false;
    }

    //첫 씬 전환 함수
    public void Close(){
        SceneManager.LoadScene("Start");
    }
}