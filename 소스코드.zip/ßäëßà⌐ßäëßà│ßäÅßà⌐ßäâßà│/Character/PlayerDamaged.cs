﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Player의 Damaged되는 상황에 대한 Script
//PlayerState.cs, PlayerMovement.cs와 연동
//빌런과 부딪힌 경우 && 오염된 마스크와 부딪힌 경우, isAttacked로 간주
//빌런과 부딪힌 경우, 레벨에 따른 HP 감소량 차등

public class PlayerDamaged : MonoBehaviour
{
    [SerializeField]    private PlayerState playerState;
    [SerializeField]    private PlayerOperation playerOperation;
    [SerializeField]    private CanvasGroup damagedRed;

    public bool isAttacked;
    private bool isDamage;
    private float damageTime = 0.2f;

    void FixedUpdate(){
        if(isDamage){
            if(damageTime < 0){
                isDamage = false;
                damagedRed.alpha = 0;
                damageTime = 0.2f;
            }
            damageTime -= Time.deltaTime;
        }
    }

    //빌런과 부딪힌 경우, PlayerAnimation 정보를 관리하고 있는 PlayerMovement.cs에서 
    //index(animation information)을 가져와서 index==0, index==2인 경우(마스크를 안쓴경우)와 
    //index==3. index==1인 경우(마스크를 쓴경우)로 나눠서 빌런의 level에 따라 HP차감 정도를 나눴다.
    //HP 차감 관리는 PlayerState.cs에서 하기 때문에 연결시켜서 변수를 넘겨준다. (매개변수: 차감율)

    void OnCollisionEnter2D(Collision2D other){
        if(other.gameObject.CompareTag("level0")){
            AttackedByLevel(0);
        }
        else if(other.gameObject.CompareTag("level1")){
            AttackedByLevel(1);
        }
        else if(other.gameObject.CompareTag("level2")){
            AttackedByLevel(2);
        }
        else if(other.gameObject.CompareTag("level3")){
            AttackedByLevel(3);
        }
    }

    void AttackedByLevel(int level){
        isAttacked = true;
        PaintRed();
        if(playerOperation.index == 0 || playerOperation.index == 2){
            switch (level){
            case 0: 
                playerState.SetHP(5, 1); //hp 차감
                break;
            case 1:
                playerState.SetHP(10, 1); //hp 차감
                break;
            case 2: 
                playerState.SetHP(15, 1); //hp 차감
                break;
            case 3:
                playerState.SetHP(30, 1); //hp 차감
                break;
            default:
                break;
            }
        }else if(playerOperation.index == 1 || playerOperation.index == 3){
            switch (level){
            case 1:
                playerState.SetHP(5, 1);  //hp 차감
                break;
            case 2: 
                playerState.SetHP(7, 1);  //hp 차감 
                break;
            case 3:
                playerState.SetHP(15, 1); //hp 차감    
                break;
            default:
                break;
            }
        }
    }    
    
    void PaintRed(){
        damagedRed.alpha = 1;
        isDamage = true;
    }

    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.CompareTag("trick")){   //오염된 마스크를 밟은 경우
            isAttacked = true;
            PaintRed();
            playerState.SetHP(10, 1); //hp 차감
        }
    }

    //감염 범위에서 벗어난 경우
    void OnCollisionExit2D(Collision2D other){
        isAttacked = false;
    }
    void OnTriggerExit2D(Collider2D other){
        isAttacked = false;
    }
}