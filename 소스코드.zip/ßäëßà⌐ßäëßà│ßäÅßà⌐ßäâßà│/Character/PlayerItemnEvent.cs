﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//player의 item과 event 관련 script
//Inventory.cs, PlayerMovement.cs, PlayerState.cs 와 연결
//map 함수, 
//item, event와 관련 audio

public class PlayerItemnEvent : MonoBehaviour
{
    [SerializeField]    private Inventory theInventory;
    [SerializeField]    private PlayerOperation playerOperation;
    [SerializeField]    public CanvasGroup[] canvasGroup;  //message, map, PICKUP, pause, tutorial1, tutorial2, numberTicket, clickAction
    [SerializeField]    private GameObject[] doors;         //home door, boss door
    [SerializeField]    private PlayerState playerState;
    [SerializeField]    private FadeEffect fadeEffect2;
    [SerializeField]    public float[] map_location, real_location; //left, right, down, up
    [SerializeField]    private Image[] TimeCount; //티켓 카운트: 195, 196, 197, 198, 199, 200
    [SerializeField]    private AudioSource[] audioSound; //office_audio, numberTicket_sound
    public AudioSource bgm; //아이템, 이벤트에 관한 오디오
    
    
    //event state 부울 변수()
    private bool collision, door, isPause, tutorial1, tutorial2, isMap;
    private GameObject taken_item, door_object, ticket; //아이템 오브젝트
    public GameObject pos, fadeOut1, office_audio_off; 


    //map system 변수
    private float map_width, map_height, real_width, real_height; // 가로, 세로 길이
    private Image image;
    public bool playerStop;
    private bool closeStart, ticketCountDown, ticketTimeCountDown, getTicket,fade_start;
    public bool chasingStart;
    private float closeTime= 2.0f, ticketTime = 2.0f; 
    private int ticketNumber = 195, TimeIndex=0;
    
    [SerializeField]
    private Text message;  //system message

    void Awake(){
        map_width = map_location[1]-map_location[0];
        map_height = map_location[3]-map_location[2];
        real_width = real_location[1]-real_location[0];
        real_height = real_location[3]-real_location[2];

        for(int i=0; i<TimeCount.Length; i++){
            TimeCount[i].enabled = false;
        }
        image = fadeOut1.GetComponent<Image>();
        office_audio_off.SetActive(false);
    }

    //티켓 수집 이벤트 함수
    public void GetTicket(){
        if(getTicket){
            canvasGroup[2].alpha = 1;
            message.text = "접수 번호는 '200'번 입니다.";
            ticket.SetActive(false);
            ticketCountDown = true;
            canvasGroup[6].alpha = 1;
            TimeCount[TimeIndex].enabled = true;
        }
    }

    //아이템 수집 이벤트 함수
    public void PickUp(){
        if(collision){
            canvasGroup[2].alpha = 1;
            message.text = "'" + taken_item.name + "'를(을) 주웠습니다.";
            theInventory.AcquireItem(taken_item.transform.GetComponent<ItemPickUp>().items);
            taken_item.SetActive(false);
        }
    }

    //문 열림관련 이벤트 함수
    public void OpenDoor(){
        if(door){
            canvasGroup[2].alpha = 1;

            if(door_object.name == "HomeDoor") {
                doors[0].SetActive(false);
                message.text = "문이 열렸습니다.";
            }
            else if(door_object.name == "BossDoor") {
                doors[1].SetActive(false);
                message.text = "문이 열렸습니다.";
            }
            else if(door_object.name == "doctor_door"){
                message.text = "완료! 백신을 맞을 차례입니다.";
                fadeOut1.SetActive(true);
                StartCoroutine(fadeEffect2.Fade(0,1));
            }
        }
    }

    void FixedUpdate(){
        if(playerOperation.isZ || playerOperation.isdoor || playerOperation.isTicket){
            closeStart = true;
        }

        //제한 시간 지난 후, 메세지창 닫기
        if(closeStart){
            if(closeTime <= 0){
                canvasGroup[2].alpha = 0;
                closeStart = false;
                closeTime = 2.0f;
                playerOperation.SetDefault();
            }
            else
                closeTime -= Time.deltaTime;
        }

        //챕터3의 티켓 수집 후 발생하는 이벤트 관련 명령어들
        if(ticketCountDown){
            if(ticketNumber == 200){
                chasingStart = true;
                bgm.pitch = 3.0f;
            }
            else{
                ticketTimeCountDown = true;
            }
        }

        //티켓 카운트 다운
        if(ticketTimeCountDown){
            if(ticketTime <= 0){
                ticketTimeCountDown = false;
                ticketTime = 2.0f;
                ticketNumber++;
                TimeCount[TimeIndex++].enabled=false;
                TimeCount[TimeIndex].enabled= true;
                audioSound[1].Play();
            }
            else{
                ticketTime -= Time.deltaTime;
            }
        }

        //에필로그 이벤트
        if (fadeEffect2.gotoEpilogue)
            SceneManager.LoadScene("epilogue");
    }

    //이벤트 UI 닫기 함수 - 마우스
    public void CloseSystem(){
        if(isPause){
            Time.timeScale = 1.0f;
            canvasGroup[3].alpha = 0;
            canvasGroup[3].interactable = false;
            canvasGroup[3].blocksRaycasts = false;  
            isPause = false;  
        }
        else if(tutorial1){
            Time.timeScale = 1.0f;
            canvasGroup[4].alpha = 0;
            canvasGroup[4].interactable = false;
            canvasGroup[4].blocksRaycasts = false;  
            tutorial1 = false;
        }
        else if(tutorial2){
            Time.timeScale = 1.0f;
            canvasGroup[5].alpha = 0;
            canvasGroup[5].interactable = false;
            canvasGroup[5].blocksRaycasts = false;  
            tutorial2 = false;
        }  
    }

    //게임 정지 이벤트 함수
    public void Pause(){
        isPause = true;
        Time.timeScale = 0.0f;
        canvasGroup[3].alpha = 1;
        canvasGroup[3].interactable = true;
        canvasGroup[3].blocksRaycasts = true;
    }

    //맵 함수
    public void Map(){
        if(playerOperation.isMap){
            Vector2 position = pos.transform.localPosition;
            position.x = map_location[0] + (transform.position.x - real_location[0])/real_width*map_width;
            position.y = map_location[2] + (transform.position.y - real_location[2])/real_height*map_height;
            pos.transform.localPosition = position;
            canvasGroup[1].alpha = 1;
        }
        else{
            canvasGroup[1].alpha = 0;
        }
    }

    //player와 아이템과 부딪힌 경우
    void OnTriggerStay2D(Collider2D other){
        if(other.gameObject.CompareTag("item")){                        //아이템
            collision = true;
            taken_item = other.gameObject;
        }else if(other.gameObject.CompareTag("door")){                  //문
            door_object = other.gameObject;
            door = true;
        }else if(other.gameObject.CompareTag("numberTicket")){          //(병원)넘버티켓
            getTicket = true;
            ticket = other.gameObject;
            canvasGroup[7].alpha = 1;
        }else if(other.gameObject.CompareTag("elevator")){              //엘리베이터
            canvasGroup[7].alpha = 1;
        }
        else if(other.gameObject.CompareTag("office_sound_on")){        //회사 오디오 On
            audioSound[0].Play();
            office_audio_off.SetActive(true);
        }
        else if(other.gameObject.CompareTag("office_sound_off")){       //회사 오디오 Off
            audioSound[0].Stop();
        }
        else if(other.gameObject.CompareTag("tutorial")){               //튜토리얼
            other.gameObject.SetActive(false);
            Time.timeScale = 0.0f;
            if(other.gameObject.name.Equals("tutorial1")){
                tutorial1 = true;
                canvasGroup[4].alpha = 1;
                canvasGroup[4].interactable = true;
                canvasGroup[4].blocksRaycasts = true;
            }
            else if(other.gameObject.name.Equals("tutorial2")){
                tutorial2 = true;
                canvasGroup[5].alpha = 1;
                canvasGroup[5].interactable = true;
                canvasGroup[5].blocksRaycasts = true;
            }
        }  
    }

    void OnCollisionEnter2D(Collision2D other){
        if(other.gameObject.CompareTag("elevator")){
            transform.parent = other.gameObject.transform;
        }
    }

    void OnCollisionExit2D(Collision2D other){
        if(other.gameObject.CompareTag("elevator")){
            transform.parent = null;
        }
    }
    
    void OnTriggerExit2D(Collider2D other){
        collision = false;
        door = false;
        canvasGroup[7].alpha = 0;
    }
}
