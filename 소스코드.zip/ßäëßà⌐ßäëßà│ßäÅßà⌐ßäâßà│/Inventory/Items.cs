﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//아이템 정보

[CreateAssetMenu(fileName="New Item", menuName="Resources/Item")]
public class Items : ScriptableObject
{   
    //아이템 유형
    public enum ItemType{
        mask,
        pill,
    }

    public string item_name;    //아이템 이름 - 한글
    public int feature;         //마스크: 제한 시간 길이. 면역제: hp 증가량
    public ItemType itemType;   //아이템 유형 [마스크, 면역제]
    public Sprite itemImage;    //아이템 이미지 (인벤토리에 띄울)
}
