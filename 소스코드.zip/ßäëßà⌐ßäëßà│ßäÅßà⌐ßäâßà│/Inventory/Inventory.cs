﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//Inventory 총괄 script

public class Inventory : MonoBehaviour
{
    [SerializeField]    private GameObject go_SlotsParents; //Slot들(3~4개)의 부모인 Grid Setting
    private Slots[] _slots;  //슬롯들 배열
    
    void Start(){
        //슬롯들을 slots배열에 할당
        //GetComponentsInChildren을 사용하여 자식들 중에 Slot인 애들을 모두 찾아 배열로 할당
        _slots = go_SlotsParents.GetComponentsInChildren<Slots>();
    }

    //아이템 습득하기
    public void AcquireItem(Items _item, int _count = 1){
        //같은 종류의 아이템이 이미 있는지 검사. 있다면 아이템 개수 더해주기
        for(int i=0; i<_slots.Length; i++){
            if(_slots[i].items != null){ //null이라면 slots[i].item.itemName할 때 런타임 에러
                //같은 종류의 아이템 슬롯을 인벤토리에서 찾았다면(이름이 같다면)
                if(_slots[i].items.item_name == _item.item_name){
                    //해당 슬롯의 아이템 개수 업데이트(Slots.cs의 SetSlotCount()호출)
                    _slots[i].SetSlotCount(_count);
                    return;
                }
            }
        }

        //같은 종류의 아이템이 없다면, 아이템을 저장할 새로운 슬롯 마련
        for(int i=0; i<_slots.Length; i++){
            //빈 슬롯 찾기
            if(_slots[i].items == null){
                //빈 슬롯을 찾았다면 Slots.cs AddItem()호출
                _slots[i].AddItem(_item, _count);
                return;
            }
        }
    }
}