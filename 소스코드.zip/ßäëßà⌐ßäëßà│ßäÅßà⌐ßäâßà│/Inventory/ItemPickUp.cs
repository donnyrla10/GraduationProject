﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//아이템 오브젝트에 붙여서 아이템이라는 것을 명시해줌
public class ItemPickUp : MonoBehaviour
{
    public Items items;
}
