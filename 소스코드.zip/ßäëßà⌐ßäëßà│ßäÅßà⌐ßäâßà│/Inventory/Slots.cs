﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//슬롯 1개 script

public class Slots : MonoBehaviour
{
    public Items items; //획득한 아이템
    public int itemCount=0; //획득한 아이템의 개수
    public Image itemImage; //획득한 아이템의 이미지

    [SerializeField]    private Text text_count;
    [SerializeField]    private PlayerState playerState;
    [SerializeField]    private GameObject go_CountImage;
    

    //아이템 이미지 투명도 조절
    //아이템이 없는 슬롯이면 아이템 이미지 Item_image의 현재 sprite 이미지도 할당되어 있지 않고 투명도가 0인 상태이기 때문에
    //아이템이 슬롯에 추가되면 투명도를 다시 불투명하게 올려줘야 한다.
    private void SetColor(float _alpha){
        Color color = itemImage.color;
        color.a = _alpha;
        itemImage.color = color;
    }

    //인벤토리에 새로운 아이템 슬롯 추가(해당 슬롯에 새로운 아이템 추가//슬롯에 아이템없던 상태였다가 처음으로 들어오는 경우)
    public void AddItem(Items _item, int _count = 1){
        //아이템, 아이템 이름, 아이템 개수, 아이템 이미지 sprite 할당
        items = _item;
        itemCount = _count;
        itemImage.sprite = items.itemImage;
        go_CountImage.SetActive(true);              //아이템 개수 표시 이미지 활성화
        text_count.text = itemCount.ToString();
        SetColor(1);                                //슬롯에 아이템이 들어왔으니, 불투명하게.
    }

    //해당 슬롯의 아이템 개수 업데이트(이미 있는 아이템 추가시, 개수 업데이트)
    public void SetSlotCount(int _count){
        itemCount += _count;                        //개수 합산, 텍스트 업데이트
        text_count.text = itemCount.ToString();
        if(itemCount<=0){                           //아이템이 없을 경우 해당 슬롯 삭제
            ClearSlot();
        }
    }

    //해당 슬롯 하나 삭제
    public void ClearSlot(){
        //아이템, 개수, 이미지 초기화
        items = null;
        itemCount = 0;
        itemImage.sprite = null;

        SetColor(0);                         //아이템 이미지를 투명하게.
    
        text_count.text = "0";              //아이템 개수 이미지 비활성화
        go_CountImage.SetActive(false);
    }

    public void UseItem(){ //아이템 사용 기능
        //면역제라면
        if(items.itemType == Items.ItemType.pill){
            playerState.SetHP(5, 0);
            SetSlotCount(-1);    
        }
        //마스크라면
        if(items.itemType == Items.ItemType.mask){
            playerState.UseMask(30);
            SetSlotCount(-1);    
        } 
    }

}
