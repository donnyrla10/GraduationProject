﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//회사 문 열리고 닫히는 스크립트

public class DoorOpen : MonoBehaviour
{
    Animator animator;
    
    void Start(){
        animator = GetComponent<Animator>();   
    }

    public void SetOpen(){
        animator.SetBool("IsOpen",true);
    }

    public void SetClose(){
        animator.SetBool("IsOpen",false);
    }
}
