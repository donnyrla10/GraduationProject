﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//프롤로그 script

public class Prologue : MonoBehaviour
{
    [SerializeField]    private CanvasGroup prologue;
    [SerializeField]    private CanvasGroup afterFewMonth;
    [SerializeField]    private CanvasGroup[] news;

    private bool end=false, end2=false, month = false;
    private float time = 18, monthTime = 4;

    void FixedUpdate(){

        //프롤로그 시간 조절
        if(!end){
            if(prologue.alpha <= 1) 
                prologue.alpha += 0.5f*Time.deltaTime;
        }else{
            if(prologue.alpha > 0) 
                prologue.alpha -= Time.deltaTime;
            else                   
                month = true;
        }

        if(time <= 16 && time > 12)
            news[0].alpha = 1;
        else if(time <= 12 && time > 9){
            news[0].alpha = 0;
            news[1].alpha = 1;
        }
        else if(time <= 9 && time > 6){
            news[1].alpha = 0;
            news[2].alpha = 1;
        }
        else if(time <= 6 && time > 3){
            news[2].alpha = 0;
            news[3].alpha = 1;            
        }
        else if(time <= 3 && time > 0){
            news[3].alpha = 0;
            news[4].alpha = 1;
        }
        else
            news[4].alpha = 0;
        
        if(time > 0)    
            time -= Time.deltaTime;
        else
            end = true;
        
        //몇 달 뒤 애니메이션
        if(month){
            if(!end2){
                if(afterFewMonth.alpha <= 1)     
                    afterFewMonth.alpha += 0.5f*Time.deltaTime;
            }
            else{
                if(afterFewMonth.alpha > 0)     
                    afterFewMonth.alpha -= Time.deltaTime;
                else                            
                    SceneManager.LoadScene("Chapter01");
            }

            if(monthTime > 0)    
                monthTime -= Time.deltaTime;
            else                 
                end2 = true;
        }
    }
}
