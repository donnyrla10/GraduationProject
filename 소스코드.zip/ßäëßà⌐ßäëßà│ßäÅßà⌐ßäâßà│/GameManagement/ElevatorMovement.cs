﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//회사 엘리베이터 이동 script

public class ElevatorMovement : MonoBehaviour
{
    public Transform player;
    public Transform elevatorSwitch;
    public Transform downpos;
    public Transform uppperpos;

    public float speed; 
    bool iselevatordown; 

    void FixedUpdate(){
        StartElevator();
    } 

    void StartElevator(){
        if(Vector2.Distance(player.position, elevatorSwitch.position) < 1f && Input.GetKeyDown("7")) {
            if(transform.position.y <= downpos.position.y)
                iselevatordown = true;
            else if(transform.position.y >= uppperpos.position.y)
                iselevatordown = false;
        }

        if(iselevatordown)
            transform.position = Vector2.MoveTowards(transform.position, uppperpos.position, speed*Time.deltaTime);
        else
            transform.position = Vector2.MoveTowards(transform.position, downpos.position, speed*Time.deltaTime);
    
    }
}
