﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

//게임메뉴 스크립트

public enum Btn{
    Start, Restart, Close, Continue, Guide1, Guide2
}

public class BtnClick : MonoBehaviour{
    public Btn BType; // 버튼 종류
    public CanvasGroup popupGroup;
    public CanvasGroup tutorialGroup;

    [SerializeField]    private FadeEffect fadeEffect;
    [SerializeField]    private PlayerItemnEvent player_pick;
    public GameObject fadeOut;
    private Image image;
    private bool fade_start = false;

    void Awake(){
        image = fadeOut.GetComponent<Image>();
    }

    void FixedUpdate(){
        if(image.color.a == 1)    fade_start = true;
        
        if(fade_start) {
            fade_start=false;
            SceneManager.LoadScene("Prologue");
        }
    }

    public void OnBtnClick(){
        switch (BType){
        case Btn.Start:
            fadeOut.SetActive(true);
            StartCoroutine(fadeEffect.Fade(0,1));     
            break;
        case Btn.Restart:
            CanvasGroupOff(popupGroup);
            SceneManager.LoadScene("Start");
            break;
        case Btn.Close:
            CanvasGroupOff(popupGroup);
            break;
        case Btn.Continue:
            CanvasGroupOff(popupGroup);
            player_pick.CloseSystem();
            break;
        case Btn.Guide1:
            CanvasGroupOff(popupGroup);
            CanvasGroupOn(tutorialGroup);
            break;
        case Btn.Guide2:
            CanvasGroupOff(popupGroup);
            CanvasGroupOn(tutorialGroup);
            break;
        }
    }

    // option 메뉴 끄고 키고 할 때 쓸 그룹 관리 함수
    public void CanvasGroupOn(CanvasGroup cg){
        cg.alpha = 1; // 투명도 (1일때 보임)
        cg.interactable = true;
        cg.blocksRaycasts = true;
    }
    public void CanvasGroupOff(CanvasGroup cg){
        cg.alpha = 0; // 투명도 (0일때 투명)
        cg.interactable = false;
        cg.blocksRaycasts = false;
    }
}