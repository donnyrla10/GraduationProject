﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//회사 자동문 트리거 스크립트

public class DoorTrigger : MonoBehaviour{
    public DoorOpen theDoorOpen;

    void OnTriggerEnter2D(Collider2D other){
        if (other.gameObject.CompareTag("Player"))
            theDoorOpen.SetOpen();
    }
    void OnTriggerExit2D(Collider2D other){
        if (other.gameObject.CompareTag("Player"))
            theDoorOpen.SetClose();
    }
}
