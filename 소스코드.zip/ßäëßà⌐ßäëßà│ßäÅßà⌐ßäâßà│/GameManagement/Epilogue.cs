﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//에필로그 애니메이션 시간과 끝 조정

public class Epilogue : MonoBehaviour
{
    [SerializeField]    private CanvasGroup epilogue;
    [SerializeField]    private CanvasGroup TheEnd;
    private float timeLimit = 7.0f, endTime = 5.0f;
    private bool start = true, endStart = false, end = false;

    void FixedUpdate(){
        if(start){
            if(epilogue.alpha <= 1) epilogue.alpha += 0.5f * Time.deltaTime;
        }else {
            if(epilogue.alpha > 0) epilogue.alpha -= Time.deltaTime;
            else                   endStart = true;
        }

        if(timeLimit > 0)    timeLimit -= Time.deltaTime;
        else                 start = false;
        
        if(endStart){
            if(!end){
                if(TheEnd.alpha <= 1) TheEnd.alpha += 0.5f*Time.deltaTime;
            }else{
                if(TheEnd.alpha > 0) TheEnd.alpha -= Time.deltaTime;
            }
            if(endTime > 0)    endTime -= Time.deltaTime;
            else               end = true;
        }
    }
}
