﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//퀘스트 스크립트

public class QuestChange : MonoBehaviour{
    [SerializeField]    private GameObject[] quests; // quest 1-6 
    [SerializeField]    private GameObject[] colliders; // colliders 1-6, lightonCollider
    [SerializeField]    private GameObject alarmUI;
    [SerializeField]    private GameObject[] Glight; //global light, player point light, office light
    [SerializeField]    public Text message;

    public CanvasGroup m_group;
    public GameObject fade_collider;
    public PlayerOperation playerOperation;
    public AudioSource message_sound;

    public bool isclose, isQ4, Q4 = false;
    private float closeTime=3.0f;
    private float downTime=1.2f;
    private float afterTime = 5.0f; // quest4 collider 부딪히고 나서 시간 지난 후 퀘스트 알림 줄 예정

    void Awake(){
        if(SceneManager.GetActiveScene().name.Equals("Chapter01")){
            Glight[1].SetActive(false);
            Glight[2].SetActive(false);
            colliders[6].SetActive(false);
        }
    }

    void FixedUpdate(){
        if(playerOperation.new_quest){
            if(downTime <= 0) {
                isclose = true;
                m_group.alpha = 1;
                playerOperation.new_quest = false;
                downTime = 1.2f; 
            }
            else
                downTime -= Time.deltaTime;
        }

        if(isclose){
            if(closeTime <= 0){
                m_group.alpha = 0;
                isclose = false;
                closeTime = 3.0f;
            }
            else
                closeTime -= Time.deltaTime;
        }

        if(isQ4){
            if(afterTime <=0){
                isQ4 = false;
                afterTime = 5.0f;
                Q4 = true;
            }
            else
                afterTime -= Time.deltaTime;
            
        }

        if (Q4){
            colliders[6].SetActive(true);
            alarmUI.SetActive(true);
            message_sound.Play();
        }
    }


    public void OnTriggerEnter2D(Collider2D other) {
        switch(other.gameObject.tag) {
        case "quest1":
            alarmUI.SetActive(true);
            message_sound.Play();
            quests[0].SetActive(true);
            colliders[0].SetActive(false);
            message.text = "출근을 하기 위해 필요한 마스크와 영양제를 챙겨주세요";
            playerOperation.alarm = 0;
            break;
        case "quest2":
            alarmUI.SetActive(true);
            message_sound.Play();
            quests[0].SetActive(false);
            quests[1].SetActive(true);
            colliders[1].SetActive(false);
            message.text = "빌런을 피해 무사히 회사에 출근해주세요";
            playerOperation.alarm = 0;
            break;
        case "quest3":
            alarmUI.SetActive(true);
            message_sound.Play();
            quests[1].SetActive(false);
            quests[2].SetActive(true);
            colliders[2].SetActive(false);
            message.text = "김과장님 방에 들어가 업무보고를 진행해주세요";
            playerOperation.alarm = 0;
            break;
        case "make_quest4":
            colliders[3].SetActive(true);
            break;
        case "quest4":
            isQ4 = true;
            fade_collider.SetActive(true);
            quests[2].SetActive(false);
            quests[3].SetActive(true);
            colliders[3].SetActive(false);
            message.text = "퇴근 시간입니다. 빌런을 피해 무사히 집에 도착하세요";
            playerOperation.alarm = 0;
            Glight[0].SetActive(false);
            Glight[2].SetActive(true);
            break;
        case "lighton":
            Glight[1].SetActive(true);
            break;
        case "quest5":
            alarmUI.SetActive(true);
            message_sound.Play();
            quests[3].SetActive(false);
            quests[4].SetActive(true);
            colliders[4].SetActive(false);
            playerOperation.alarm = 0;
            break;
        case "quest6":
            alarmUI.SetActive(true);
            message_sound.Play();
            quests[4].SetActive(false);
            quests[5].SetActive(true);
            colliders[5].SetActive(false);
            playerOperation.alarm = 0;
            break;
        }
    }
}
