﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public enum FadeState { FadeIn = 0, FadeOut}

public class FadeEffect : MonoBehaviour
{
    [SerializeField]
    [Range(0.01f,10f)]
    private float fadeTime; //fadeSpeed 값이 10이면 1초 (값이 클수록 빠름)
    [SerializeField]
    private AnimationCurve fadeCurve; // 페이드 효과가 적용되는 알파값을 곡선의 값으로 설정

    private Image image; //ㅍㅔ이드 효과에 사용되는 검은 바탕 이미지
    public Color color;
    private FadeState fadeState; // 페이드 효과 상태
    public bool gotoEpilogue;

    private void Awake(){
        image = GetComponent<Image>();
        color = image.color;
    }
    
    public void OnFade(FadeState state){
        fadeState = state;

        switch (fadeState){
        case FadeState.FadeIn:
            StartCoroutine(Fade(1,0));
            break;
        case FadeState.FadeOut:
            StartCoroutine(Fade(0,1));
            break;
        }
    }

    public IEnumerator Fade(float start, float end){
        float currentTime = 0.0f;
        float percent = 0.0f;

        while (percent < 1){
            //fadeTime으로 나누어서 fadeTime 시간 동안 percent값이 0에서 1로 증가 
            currentTime += Time.deltaTime;
            percent = currentTime / fadeTime;

            // 알파값을 start 부터 end까지 fadeTime 동안 변화시킨다
            color.a = Mathf.Lerp(start, end, fadeCurve.Evaluate(percent));
            image.color = color;

            yield return null;
        }
        if(percent == 1)            gotoEpilogue = true;
    }
}