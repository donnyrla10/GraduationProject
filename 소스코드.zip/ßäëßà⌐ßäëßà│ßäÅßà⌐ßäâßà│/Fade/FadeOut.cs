﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class FadeOut : MonoBehaviour
{
    public FadeEffect fadeEffect1;
    public GameObject fadeOut;
    private Image image;

    private bool fade_start;

    void Awake()
    {
        image = fadeOut.GetComponent<Image>();
    }
    void FixedUpdate()
    {
        if (image.color.a == 1)
        {
            fade_start = true;
        }
 
        if(fade_start)
        {
            fade_start = false;
            SceneManager.LoadScene("Chapter02");
        }
    }
    public void OnTriggerEnter2D(Collider2D other) {
        if(other.gameObject.tag == "fade"){
            fadeOut.SetActive(true);
            StartCoroutine(fadeEffect1.Fade(0,1));
        }
    
    }
}
