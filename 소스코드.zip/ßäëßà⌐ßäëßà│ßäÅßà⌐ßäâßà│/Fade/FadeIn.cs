﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class FadeIn : MonoBehaviour
{

    public FadeEffect fadeEffect;
    public GameObject fadeIn;
    private Image image;

    private void Start()
    {
        image = fadeIn.GetComponent<Image>();
        StartCoroutine(fadeEffect.Fade(1,0));
    }
    private void FixedUpdate()
    {
        if (image.color.a == 0)
        {
            fadeIn.SetActive(false);
        }
    }
}