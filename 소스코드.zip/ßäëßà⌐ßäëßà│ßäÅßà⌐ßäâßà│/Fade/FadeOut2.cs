﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class FadeOut2 : MonoBehaviour
{
    private FadeEffect fadeEffect2;
    public GameObject fadeOut2;
    private Image image;

    private bool fade_start;

    void Awake()
    {
        image = fadeOut2.GetComponent<Image>();
    }
    void FixedUpdate()
    {
        if (image.color.a == 1)
        {
            fade_start = true;
        }
 
        if(fade_start)
        {
            fade_start = false;
            SceneManager.LoadScene("Prologue");
        }
    }
    public void OnTriggerEnter2D(Collider2D other) {
        if(other.gameObject.tag == "fade"){
            fadeOut2.SetActive(true);
            StartCoroutine(fadeEffect2.Fade(0,1));
        }
    }
}
